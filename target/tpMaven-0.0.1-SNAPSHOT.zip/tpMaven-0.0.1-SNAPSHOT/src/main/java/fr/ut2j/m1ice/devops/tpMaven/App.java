package fr.ut2j.m1ice.devops.tpMaven;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
        System.out.println( "Starting APP ...." );
        JXBusyLabelTest.main(null);
    }
}
